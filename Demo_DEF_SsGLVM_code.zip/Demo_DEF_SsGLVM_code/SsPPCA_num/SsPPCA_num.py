import numpy as np
import scipy.io as sio
import torch
import torch.distributions as dist
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# ---------- 中文字体设置 ----------
try:
    font = fm.FontProperties(family='SimHei')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except:
    try:
        font = fm.FontProperties(family='Microsoft YaHei')
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
    except:
        import warnings
        warnings.filterwarnings('ignore')

# ---------- 随机种子与设备 ----------
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Using device: {device}')

# ==================== 1. 加载数据 ====================
data = sio.loadmat('Hetero_dataset_1.mat')
X_all = data['X'].astype(np.float32)  # (4, 2000) 或 (2000, 4)
Y_all = data['Y'].astype(np.float32)

X = data['X'].astype(np.float32)  # (4, 2000) 或 (2000, 4)
Y = data['Y'].astype(np.float32)
# 统一形状为 (样本数, 特征数)
if X_all.shape[0] != 2000:
    X_all = X_all.T  # (2000, 4)
if Y_all.shape[0] != 2000:
    Y_all = Y_all.T  # (2000, 1)

print(f'Data shapes: X = {X_all.shape}, Y = {Y_all.shape}')

# ==================== 2. 数据划分 ====================
train_X_full = X_all[:1000, :]   # (1000, 4)
train_Y_full = Y_all[:1000, :]   # (1000, 1)
val_X   = X_all[1000:1500, :]    # (500, 4)
val_Y   = Y_all[1000:1500, :]    # (500, 1)
test_X  = X_all[1500:2000, :]    # (500, 4)
test_Y  = Y_all[1500:2000, :]    # (500, 1)

print(f'原始训练集样本数: {train_X_full.shape[0]}, 验证集: {val_X.shape[0]}, 测试集: {test_X.shape[0]}')

# ==================== 3. 标签率调节（半监督设置）====================
label_rate = 0.2          # 可调节，0.1 表示每 10 个取一个有标签
step = int(round(1 / label_rate))
indices = np.arange(0, train_X_full.shape[0], step)  # 有标签索引
mask_labeled = np.zeros(train_X_full.shape[0], dtype=bool)
mask_labeled[indices] = True
mask_unlabeled = ~mask_labeled

X_labeled = train_X_full[mask_labeled, :]   # (M1, 4)
Y_labeled = train_Y_full[mask_labeled, :]   # (M1, 1)
X_unlabeled = train_X_full[mask_unlabeled, :]  # (M2, 4)

N1 = X_labeled.shape[0]
N2 = X_unlabeled.shape[0]
print(f'标签率: {label_rate:.2f}, 有标签样本数: {N1}, 无标签样本数: {N2}')

# ==================== 4. 去均值（按原 MATLAB 逻辑）====================
u_x = torch.tensor(np.mean(np.vstack([X_labeled, X_unlabeled]), axis=0), dtype=torch.float32, device=device)  # (4,)
u_y = torch.tensor(np.mean(Y_labeled, axis=0), dtype=torch.float32, device=device)                           # (1,)

# 中心化
X_l = torch.tensor(X_labeled, dtype=torch.float32, device=device) - u_x  # (N1,4)
Y_l = torch.tensor(Y_labeled, dtype=torch.float32, device=device) - u_y  # (N1,1)
X_u = torch.tensor(X_unlabeled, dtype=torch.float32, device=device) - u_x  # (N2,4)

# 验证集和测试集也去均值（用于预测）
X_val = torch.tensor(val_X, dtype=torch.float32, device=device) - u_x
Y_val = torch.tensor(val_Y, dtype=torch.float32, device=device) - u_y
X_test = torch.tensor(test_X, dtype=torch.float32, device=device) - u_x
Y_test = torch.tensor(test_Y, dtype=torch.float32, device=device) - u_y

# ==================== 5. EM 算法参数 ====================
D_x = 4
D_y = 1
M = 4  # 潜在因子维度，可调

maxIter = 500
tol = 1e-6

# 初始化参数
W_x = torch.randn(D_x, M, device=device) * 0.1
W_y = torch.randn(D_y, M, device=device) * 0.1
sig2_x = torch.tensor(1.0, device=device, requires_grad=False)
sig2_y = torch.tensor(1.0, device=device, requires_grad=False)

# ==================== 6. EM 迭代 ====================
L_old = -1e20
L_history = []
converged = False

for iter in range(maxIter):
    # ----- E-step -----
    # 有标签后验
    inv_SIGMA = (W_x.T @ W_x) / sig2_x + (W_y.T @ W_y) / sig2_y + torch.eye(M, device=device)
    SIGMA = torch.linalg.inv(inv_SIGMA)  # (M, M)
    E_zi = SIGMA @ (W_x.T @ X_l.T / sig2_x + W_y.T @ Y_l.T / sig2_y)  # (M, N1)
    E_zi2 = N1 * SIGMA + E_zi @ E_zi.T  # (M, M)

    # 无标签后验
    inv_SIGMA_x = (W_x.T @ W_x) / sig2_x + torch.eye(M, device=device)
    SIGMA_x = torch.linalg.inv(inv_SIGMA_x)  # (M, M)
    E_zj = SIGMA_x @ W_x.T @ X_u.T / sig2_x  # (M, N2)
    E_zj2 = N2 * SIGMA_x + E_zj @ E_zj.T  # (M, M)

    # ----- M-step -----
    W_x = (X_l.T @ E_zi.T + X_u.T @ E_zj.T) @ torch.linalg.inv(E_zi2 + E_zj2)
    W_y = Y_l.T @ E_zi.T @ torch.linalg.inv(E_zi2)

    # 噪声方差更新
    trace_X_l = torch.trace(X_l @ X_l.T)
    trace_Wx_Ezi2_WxT = torch.trace(W_x @ E_zi2 @ W_x.T)
    trace_X_l_Wx_Ezi = torch.trace(X_l @ W_x @ E_zi)  # X * W_x * E_zi
    trace_X_u = torch.trace(X_u @ X_u.T)
    trace_Wx_Ezj2_WxT = torch.trace(W_x @ E_zj2 @ W_x.T)
    trace_X_u_Wx_Ezj = torch.trace(X_u @ W_x @ E_zj)

    sig2_x = (trace_X_l + trace_Wx_Ezi2_WxT - 2 * trace_X_l_Wx_Ezi +
              trace_X_u + trace_Wx_Ezj2_WxT - 2 * trace_X_u_Wx_Ezj) / ((N1 + N2) * D_x)

    trace_Y_l = torch.trace(Y_l @ Y_l.T)
    trace_Wy_Ezi2_WyT = torch.trace(W_y @ E_zi2 @ W_y.T)
    trace_Y_l_Wy_Ezi = torch.trace(Y_l @ W_y @ E_zi)
    sig2_y = (trace_Y_l + trace_Wy_Ezi2_WyT - 2 * trace_Y_l_Wy_Ezi) / (N1 * D_y)

    # ----- 计算对数似然（监测收敛）-----
    V_x = W_x @ W_x.T + sig2_x * torch.eye(D_x, device=device)
    V_y = W_y @ W_y.T + sig2_y * torch.eye(D_y, device=device)
    W_xy = torch.cat([W_x, W_y], dim=0)  # (D_x+D_y, M)
    V_xy = W_xy @ W_xy.T
    # 拼合分块协方差矩阵
    V_xy[:D_x, :D_x] += sig2_x * torch.eye(D_x, device=device)
    V_xy[D_x:, D_x:] += sig2_y * torch.eye(D_y, device=device)

    # 计算似然（使用多元正态）
    dist_xy = dist.MultivariateNormal(torch.zeros(D_x + D_y, device=device), covariance_matrix=V_xy)
    dist_x = dist.MultivariateNormal(torch.zeros(D_x, device=device), covariance_matrix=V_x)

    # 注意：数据已经中心化，均值为0
    log_prob_xy = dist_xy.log_prob(torch.cat([X_l, Y_l], dim=1)).sum()
    log_prob_xu = dist_x.log_prob(X_u).sum()
    L_new = (log_prob_xy + log_prob_xu).item()

    L_history.append(L_new)

    # 收敛判断
    if iter > 0 and abs(L_new - L_old) / max(abs(L_old), 1e-10) < tol:
        converged = True
        L_old = L_new
        print(f'Converged at iteration {iter}')
        break
    L_old = L_new

    if iter % 50 == 0:
        print(f'Iter {iter}: Log-likelihood = {L_new:.4f}')

print(f'Final Log-likelihood = {L_old:.4f}, Converged = {converged}')
if not converged:
    print('Reached max iterations without convergence')

# ==================== 7. 预测（测试集）====================
SIGMA_q = torch.linalg.inv(W_x.T @ W_x / sig2_x + torch.eye(M, device=device))
m_q = SIGMA_q @ W_x.T @ X_test.T / sig2_x  # (M, N_test)
Y_pred_centered = (W_y @ m_q).T  # (N_test, 1)
Y_pred = Y_pred_centered + u_y.unsqueeze(0)  # 加回标签均值

# 反推到原始空间（Y_test也加回均值）
Y_test_orig = Y_test + u_y.unsqueeze(0)

# ==================== 8. 性能指标 ====================
y_true = Y_test_orig.cpu().numpy().squeeze()
y_pred = Y_pred.cpu().numpy().squeeze()

y_min = Y.min()
y_max = Y.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (y_true - y_min) / (y_max - y_min)
y_pred_norm = (y_pred - y_min) / (y_max - y_min)

mse_val = np.mean((y_true_norm - y_pred_norm) ** 2)
rmse_val = np.sqrt(mse_val)
ss_res = np.sum((y_true_norm - y_pred_norm) ** 2)
ss_tot = np.sum((y_true_norm - np.mean(y_true_norm)) ** 2)
R2 = 1 - ss_res / ss_tot if ss_tot != 0 else 0

from scipy.io import savemat
file_name='Result_Num_PPCA_LR20.mat'
savemat(file_name,{'PPCA_Y':y_true_norm,'PPCA_Y_pre':y_pred_norm.astype(np.float64),'PPCA_RMSE':rmse_val,'PPCA_R2':R2})

print(f'\n测试集性能（标签率 {label_rate:.2f}）：')
print(f'  RMSE: {rmse_val:.4f}')
print(f'  MSE:  {mse_val:.6f}')
print(f'  R²:   {R2:.4f}')

# ==================== 9. 可视化 ====================
# 对数似然曲线
plt.figure(figsize=(8, 4))
plt.plot(L_history)
plt.xlabel('迭代次数')
plt.ylabel('对数似然')
plt.title('EM 算法对数似然变化')
plt.grid(True)
plt.show()

# 预测对比线图
plt.figure(figsize=(10, 5))
plt.plot(y_true, 'b-o', linewidth=1, markersize=4, label='真实值')
plt.plot(y_pred, 'r-*', linewidth=1, markersize=4, label='预测值')
plt.legend()
plt.xlabel('测试样本序号')
plt.ylabel('输出值')
plt.title(f'半监督因子分析预测结果 (标签率={label_rate:.2f})')
plt.grid(True)
plt.show()

# 散点图
plt.figure(figsize=(6, 6))
plt.scatter(y_true, y_pred)
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title(f'预测值与真实值散点图 (标签率={label_rate:.2f})')
plt.axis('square')
lims = [min(np.min(y_true), np.min(y_pred)), max(np.max(y_true), np.max(y_pred))]
plt.xlim(lims)
plt.ylim(lims)
plt.plot(lims, lims, 'k--')
plt.grid(True)
plt.show()