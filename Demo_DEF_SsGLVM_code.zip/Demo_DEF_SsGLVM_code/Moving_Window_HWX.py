# Created by SuvenH
import numpy as np

def get_Moving_Window_HWX(X1,Y1,d,h):
    d_h = int(np.max(d + h))
    N = X1.shape[0]
    dx = X1.shape[1]
    X0 = np.zeros((N - d_h, 1))
    for i in range(dx):
        Xi = np.zeros((N - d_h, 1))
        for j in range(d[i], d[i] + h[i] + 1):
            # print(j)
            x = X1[d_h - j:N - j, i]
            x = np.array([x])
            x = x.reshape(-1, 1)
            Xi = np.hstack((Xi, x))
            # print(Xi)
        X0 = np.hstack((X0, Xi[:, 1:]))
    X=X0[:,1:]
    Y=Y1[d_h:,]
    return X,Y