import numpy as np
def standardize(data):

   #  Normalize the input data (mean 0, standard deviation 1)
   #
   #  Parameter:
   #  data (numpy array or list): Input data： one-dimension or multidimensional array.
   #
   # Return:
   #  numpy array: standardized data

    data = np.array(data)  # Convert the input into a numpy array
    mean = np.mean(data, axis=0)  # calculate the mean
    std = np.std(data, axis=0)  # calculated the standard deviation
    standardized_data = (data - mean) / std  # standardize
    return standardized_data