import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as scio
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
from torch.nn.utils.parametrizations import spectral_norm
from sklearn.metrics import mean_squared_error, r2_score
from sklearn import metrics
from scipy.io import savemat

# 引入你的自定义模块
from z_score_HWX import z_score
from Moving_Window_HWX import get_Moving_Window_HWX
from scheduler import CosineAnnealingWarmupRestarts

# ==========================================
# 1. 随机种子与环境设置
# ==========================================
seed = 42
torch.manual_seed(seed)
np.random.seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using {device} device.")

# ==========================================
# 2. 数据加载与半监督预处理
# ==========================================
data_path = r'Hetero_dataset_1.mat'
X = scio.loadmat(data_path)['X']
Y = scio.loadmat(data_path)['Y']

minY = Y.min()
maxY = Y.max()

mY = np.mean(Y, axis=0)
stdY = np.std(Y, axis=0)
X = z_score(X)
Y = z_score(Y)

dx = X.shape[1]
dy = Y.shape[1]

d = np.zeros(dx, dtype=int)
h = np.zeros(dx, dtype=int)
X, Y = get_Moving_Window_HWX(X, Y, d, h)

N = Y.shape[0]
Nval = 200
Ntst = 500
Ntrn = N - Ntst - Nval

Xtrn = X[:Ntrn]
Ytrn = Y[:Ntrn]
Xval = X[Ntrn:Ntrn + Nval]
Yval = Y[Ntrn:Ntrn + Nval]
Xtst = X[Ntrn + Nval:]
Ytst = Y[Ntrn + Nval:]

# 转换为PyTorch张量
X_train_t = torch.FloatTensor(Xtrn)
y_train_t = torch.FloatTensor(Ytrn)
X_val_t = torch.FloatTensor(Xval)
y_val_t = torch.FloatTensor(Yval)
X_test_t = torch.FloatTensor(Xtst)
y_test_t = torch.FloatTensor(Ytst)

# 生成半监督 Mask (训练集)
# label_rate = 0.01  # 可调标签率
# num_train = len(X_train_t)
# num_labeled = int(label_rate * num_train)
# masks = np.zeros(num_train)
# masks[:num_labeled] = 1.0
# np.random.shuffle(masks)
# masks_t = torch.FloatTensor(masks)

label_rate = 0.2 # 可调标签率
num_train = len(X_train_t)
num_labeled = int(label_rate * num_train)
masks = np.zeros(num_train)
indices = np.linspace(0, num_train - 1, num_labeled, dtype=int)
masks[indices] = 1.0
masks_t = torch.FloatTensor(masks)

class SemiSupervisedDataset(Dataset):
    def __init__(self, u, y, mask):
        self.u, self.y, self.mask = u, y, mask

    def __len__(self):
        return len(self.u)

    def __getitem__(self, idx):
        return self.u[idx], self.y[idx], self.mask[idx]


batch_size = 128
train_loader = DataLoader(
    SemiSupervisedDataset(X_train_t, y_train_t, masks_t),
    batch_size=batch_size,
    shuffle=True
)
# 测试集不需要mask，但为了统一计算Loss，我们可以构造一个全为1的掩码
test_loader = DataLoader(
    SemiSupervisedDataset(X_test_t, y_test_t, torch.ones(len(X_test_t))),
    batch_size=batch_size,
    shuffle=False
)

# ==========================================
# 3. 网络基础组件 (新模型架构)
# ==========================================
class EncoderBase(nn.Module):
    def __init__(self, input_dim, latent_dim=4, hidden_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        self.mu = nn.Linear(hidden_dim, latent_dim)
        self.logvar = nn.Linear(hidden_dim, latent_dim)

    def forward(self, x):
        h = self.net(x)
        return self.mu(h), torch.clamp(self.logvar(h), min=-10.0, max=5.0)


class RealNVPBlock(nn.Module):
    def __init__(self, data_dim, hidden_dim):
        super().__init__()
        self.split = data_dim // 2
        self.idem = data_dim - self.split

        self.s = nn.Sequential(
            spectral_norm(nn.Linear(self.split, hidden_dim)),
            nn.ReLU(),
            spectral_norm(nn.Linear(hidden_dim, self.idem))
        )
        self.t = nn.Sequential(
            spectral_norm(nn.Linear(self.split, hidden_dim)),
            nn.ReLU(),
            spectral_norm(nn.Linear(hidden_dim, self.idem))
        )

    def forward(self, z):
        z1, z2 = z.chunk([self.split, self.idem], dim=1)
        s = self.s(z1)
        t = self.t(z1)
        z2 = z2 * torch.exp(s) + t
        log_det = s.sum(dim=1)
        return torch.cat([z1, z2], dim=1), log_det

    def inverse(self, z):
        z1 = z[:, :self.split]
        z2 = z[:, self.split:]
        s = self.s(z1)
        t = self.t(z1)
        z2 = (z2 - t) * torch.exp(-s)
        log_det = -s.sum(dim=1)
        return torch.cat([z1, z2], dim=1), log_det


class Flow(nn.Module):
    def __init__(self, latent_dim, data_dim, hidden_dim, n_blocks):
        super().__init__()
        self.projector = nn.Linear(latent_dim, data_dim)
        self.blocks = nn.ModuleList(
            [RealNVPBlock(data_dim, hidden_dim) for _ in range(n_blocks)]
        )

    def decode(self, z):
        log_det_total = 0
        h = self.projector(z)
        for b in reversed(self.blocks):
            h, logd = b.inverse(h)
            log_det_total += logd
        return h, log_det_total


class GMMPrior(nn.Module):
    def __init__(self, latent_dim, n_components=3):
        super().__init__()
        self.means = nn.Parameter(torch.randn(n_components, latent_dim))
        self.logvars = nn.Parameter(torch.zeros(n_components, latent_dim))
        self.weights = nn.Parameter(torch.ones(n_components))

    def log_prob(self, z):
        z = z.unsqueeze(1)
        means = self.means.unsqueeze(0)
        logvars = self.logvars.unsqueeze(0)
        weights = torch.softmax(self.weights, dim=0).unsqueeze(0)
        var = torch.exp(logvars)
        log_p_c = -0.5 * (torch.log(2 * torch.tensor(np.pi)) + logvars + (z - means) ** 2 / var)
        log_p_c = log_p_c.sum(dim=-1)
        return torch.logsumexp(torch.log(weights) + log_p_c, dim=-1)


# ==========================================
# 4. 双编码器 CVAE 核心模型
# ==========================================
class DualEncoder_CVAE_RealNVP(nn.Module):
    def __init__(self, u_dim, y_dim, latent_dim, hidden_dim, n_flow_blocks, n_components=3):
        super().__init__()
        self.enc_teacher = EncoderBase(input_dim=u_dim + y_dim, latent_dim=latent_dim, hidden_dim=hidden_dim)
        self.enc_student = EncoderBase(input_dim=u_dim, latent_dim=latent_dim, hidden_dim=hidden_dim)
        self.flow = Flow(latent_dim, u_dim + y_dim, hidden_dim, n_flow_blocks)
        self.prior = GMMPrior(latent_dim, n_components=n_components)

        self.register_buffer('u_dim_tensor', torch.tensor(u_dim))
        self.register_buffer('y_dim_tensor', torch.tensor(y_dim))

        # 损失函数的权重参数
        self.alpha_u = 1.0
        self.alpha_y = 50.0
        self.beta_kl = 0.05
        self.gamma_consist = 10.0

    def forward(self, u, y, mask):
        mask_expanded = mask.unsqueeze(1)

        mu_s, logvar_s = self.enc_student(u)
        var_s = torch.exp(logvar_s)
        z_s = mu_s + torch.randn_like(mu_s) * torch.sqrt(var_s)

        mu_t, logvar_t = self.enc_teacher(torch.cat([u, y], dim=1))
        var_t = torch.exp(logvar_t)
        z_t = mu_t + torch.randn_like(mu_t) * torch.sqrt(var_t)

        z_final = mask_expanded * z_t + (1 - mask_expanded) * z_s

        out_hat, log_det = self.flow.decode(z_final)
        u_hat, y_hat = out_hat[:, :self.u_dim_tensor], out_hat[:, self.u_dim_tensor:]

        # 计算多头损失
        log_q_s = -0.5 * (logvar_s + (z_s - mu_s).pow(2) / var_s).sum(dim=1)
        log_q_t = -0.5 * (logvar_t + (z_t - mu_t).pow(2) / var_t).sum(dim=1)
        log_p = self.prior.log_prob(z_final)

        kl_s = log_q_s - log_p
        kl_t = log_q_t - log_p
        kl_final = mask * kl_t + (1 - mask) * kl_s

        rec_u = (u - u_hat).pow(2).sum(dim=1)
        rec_y = (y - y_hat).pow(2).sum(dim=1)
        loss_u = rec_u.mean()

        labeled_count = mask.sum() + 1e-8
        loss_y = (rec_y * mask).sum() / labeled_count

        kl_consistency = 0.5 * (logvar_t - logvar_s + (var_s + (mu_s - mu_t).pow(2)) / var_t - 1).sum(dim=1)
        loss_consistency = (kl_consistency * mask).sum() / labeled_count

        rec_loss = self.alpha_u * loss_u + self.alpha_y * loss_y
        loss = self.beta_kl * kl_final.mean() + rec_loss - log_det.mean() + self.gamma_consist * loss_consistency

        return loss

    def predict(self, u):
        """用于在测试集上仅仅依赖 X 推断 Y"""
        self.eval()
        with torch.no_grad():
            mu_s, _ = self.enc_student(u)
            out_hat, _ = self.flow.decode(mu_s)
            y_pred = out_hat[:, self.u_dim_tensor:]
        return y_pred


# ==========================================
# 5. 模型初始化与训练配置
# ==========================================
u_dim = X_train_t.shape[-1]
y_dim = y_train_t.shape[-1]
latent_dim = 3
hidden_dim = 64
n_flow_blocks = 4
n_components = 3

model = DualEncoder_CVAE_RealNVP(u_dim, y_dim, latent_dim, hidden_dim, n_flow_blocks, n_components)
model.to(device)

epochs = 150
lr = 0.001
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
scheduler = CosineAnnealingWarmupRestarts(
    optimizer,
    first_cycle_steps=300,
    cycle_mult=1.0,
    max_lr=lr,
    min_lr=0.0001,
    warmup_steps=100,
    gamma=0.5
)

# ==========================================
# 6. 训练与测试循环
# ==========================================
train_losses = []
test_losses = []

for epoch in range(epochs):
    model.train()
    epoch_loss = 0
    epoch_test_losses = 0

    # 训练循环
    for batch_X, batch_y, batch_mask in train_loader:
        batch_X = batch_X.to(device)
        batch_y = batch_y.to(device)
        batch_mask = batch_mask.to(device)

        optimizer.zero_grad()
        loss = model(batch_X, batch_y, batch_mask)
        loss.backward()
        # 梯度裁剪防爆
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
        optimizer.step()
        epoch_loss += loss.item()

    avg_loss = epoch_loss / len(train_loader)
    train_losses.append(avg_loss)

    # 测试循环 (利用全为1的mask模拟完全监督下计算的重构和分布损失)
    model.eval()
    with torch.no_grad():
        for batch_X_t, batch_y_t, batch_mask_t in test_loader:
            batch_X_t = batch_X_t.to(device)
            batch_y_t = batch_y_t.to(device)
            batch_mask_t = batch_mask_t.to(device)

            test_loss = model(batch_X_t, batch_y_t, batch_mask_t)
            epoch_test_losses += test_loss.item()

        test_avg_loss = epoch_test_losses / len(test_loader)
        test_losses.append(test_avg_loss)

    scheduler.step()

    if (epoch + 1) % 10 == 0:
        print(f'Epoch {epoch + 1}/{epochs}, Train Loss: {avg_loss:.4f}, Test Loss: {test_losses[-1]:.4f}')

# ==========================================
# 7. 评估与可视化
# ==========================================
plt.figure(figsize=(10, 5))
plt.plot(train_losses, label='Training Loss')
plt.plot(test_losses, label='Test Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training and Test Loss (DualEncoder CVAE)')
plt.legend()
plt.grid(True)
plt.show()


def evaluate_model(model, X_test, y_test):
    X_test_t = torch.FloatTensor(X_test).to(device)

    # 预测并转回CPU NumPy
    y_pred = model.predict(X_test_t).cpu().detach().numpy()

    rmse = np.sqrt(np.mean((y_test - y_pred) ** 2))
    y_mean = np.mean(y_test)
    ss_total = np.sum((y_test - y_mean) ** 2)
    ss_res = np.sum((y_test - y_pred) ** 2)
    r2 = 1 - (ss_res / ss_total)

    return rmse, r2, y_pred


rmse, r2, y_pred = evaluate_model(model, Xtst, Ytst)
# print(f'Test RMSE: {rmse:.4f}')
# print(f'Test R2: {r2:.4f}')

plt.figure(figsize=(10, 6))
plt.plot(Ytst, label='True Values', linewidth=2)
plt.plot(y_pred, label='Predicted Values', linestyle='--')
plt.xlabel('Sample Index')
plt.ylabel('Output Value')
plt.legend()
plt.grid(True)
plt.show()

# --- 反归一化与保存 ---
Ytst = Ytst * stdY + mY
Ypre_tst = y_pred * stdY + mY

Ytst = (Ytst - minY) / (maxY - minY)
Ypre_tst = (Ypre_tst - minY) / (maxY - minY)

MSE_tst = metrics.mean_squared_error(Ytst, Ypre_tst)
RMSE_tst = np.sqrt(MSE_tst)
R2_tst = r2_score(Ytst, Ypre_tst)

#print(f'\nFinal Metrics (Max-Min Scaled):')
print(f'RMSE: {RMSE_tst:.4f}')
print(f'R2:   {R2_tst:.4f}')

file_name = 'Result_Num_SsAdap_GLVM_LR20.mat'
savemat(file_name, {
    'VAE_test': Ytst,
    'VAE_Y_pre': Ypre_tst.astype(np.float64),
    'VAE_RMSE': RMSE_tst,
    'VAE_R2': R2_tst
})
print(f"Results saved to {file_name}")