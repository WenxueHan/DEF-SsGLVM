import numpy as np
import scipy.io as sio
import torch
import torch.special as ts
import matplotlib.pyplot as plt
from scipy.special import digamma as sp_digamma  # 备用
import os
os.environ["OMP_NUM_THREADS"] = "1"
# 兼容低版本 PyTorch （若无 torch.special）
try:
    from torch.special import digamma as t_digamma
except ImportError:
    t_digamma = lambda x: torch.from_numpy(sp_digamma(x.numpy())).to(x.device, x.dtype)

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cpu')

# --------------------------- 数据加载与划分 ---------------------------
data = sio.loadmat('Hetero_dataset_1.mat')
X_all = data['X'].astype(np.float32)
Y_all = data['Y'].astype(np.float32)

X = data['X'].astype(np.float32)
Y = data['Y'].astype(np.float32)

if X_all.shape[0] < X_all.shape[1]:
    X_all = X_all.T
if Y_all.shape[0] < Y_all.shape[1]:
    Y_all = Y_all.T

X_all = torch.tensor(X_all, device=device)
Y_all = torch.tensor(Y_all, device=device)

train_X_full = X_all[:1000]      # (1000, Dx)
train_Y_full = Y_all[:1000]      # (1000, Dy)
test_X = X_all[1500:2000]
test_Y = Y_all[1500:2000]

N_train = train_X_full.shape[0]
Dx = train_X_full.shape[1]
Dy = train_Y_full.shape[1]
print(f"训练样本数: {N_train}, Dx = {Dx}, Dy = {Dy}")

# 半监督划分（标签率 0.1）
label_rate = 0.2
step = int(round(1 / label_rate))
indices = np.arange(0, N_train, step)
mask_labeled = torch.zeros(N_train, dtype=torch.bool)
mask_labeled[indices] = True

X_lab = train_X_full[mask_labeled]        # (Nl, Dx)
Y_lab = train_Y_full[mask_labeled]        # (Nl, Dy)
X_unlab = train_X_full[~mask_labeled]     # (Nu, Dx)

Nl = X_lab.shape[0]
Nu = X_unlab.shape[0]
N = Nl + Nu
print(f"有标签: {Nl}, 无标签: {Nu}")

# --------------------------- 模型初始化 ---------------------------
K = 3
maxIter = 500
tol = 1e-6

# 用有标签数据的 K-Means 初始化均值（仅 x 部分）
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=K, random_state=0, n_init=10).fit(X_lab.cpu().numpy())
init_idx = kmeans.labels_
mu = torch.zeros(K, Dx, device=device)
for k in range(K):
    cluster_x = X_lab[init_idx == k]
    if cluster_x.shape[0] > 0:
        mu[k] = cluster_x.mean(dim=0)
    else:
        mu[k] = X_lab.mean(dim=0)

# 初始化精度矩阵 Lambda （协方差逆）
Lambda = []
cov0 = torch.cov(X_lab.T) + 1e-4 * torch.eye(Dx, device=device)
for k in range(K):
    Lambda.append(torch.linalg.inv(cov0))
Lambda = torch.stack(Lambda, dim=0)   # (K, Dx, Dx)

# 自由度
v = 20.0 * torch.ones(K, device=device)

# 回归参数 g: (Dx+1, Dy) 每个分量
X_lab_wan = torch.cat([X_lab, torch.ones(Nl, 1, device=device)], dim=1)  # (Nl, Dx+1)
g = torch.zeros(K, Dx+1, Dy, device=device)
sig2 = torch.zeros(K, Dy, device=device)
for k in range(K):
    g_k = torch.linalg.lstsq(X_lab_wan, Y_lab).solution  # (Dx+1, Dy) 最小二乘
    g[k] = g_k
    y_pred = X_lab_wan @ g_k
    sig2[k] = ((Y_lab - y_pred)**2).mean(dim=0)

# 混合系数
alpha = torch.ones(K, device=device) / K

# --------------------------- 工具函数 ---------------------------
def multivariate_student_t_logpdf(x, mu, Lambda, v):
    """
    x: (N, Dx), mu: (Dx,), Lambda: (Dx, Dx) 精度矩阵, v: 标量
    返回对数密度，形状 (N,)
    """
    diff = x - mu
    delta = (diff @ Lambda * diff).sum(dim=-1)  # (N,)
    log_det_L = torch.log(torch.det(Lambda))
    log_gamma = torch.lgamma(v/2 + Dx/2) - torch.lgamma(v/2)
    log_pdf = log_gamma + 0.5*log_det_L \
              - Dx/2 * torch.log(v * torch.tensor(np.pi, device=device)) \
              - (v/2 + Dx/2) * torch.log(1 + delta / v)
    return log_pdf

def solve_v(Ck, vmin=0.5, vmax=200.0, step=50):
    """二分法求解  -digamma(v/2) + log(v/2) + 1 + Ck = 0 """
    def f(v_val):
        v_t = torch.tensor(v_val, device=device)
        return -t_digamma(v_t/2) + torch.log(v_t/2) + 1 + Ck

    lo, hi = vmin, vmax
    f_lo, f_hi = f(lo), f(hi)
    # 若根不在区间，保持原值
    if f_lo * f_hi > 0:
        return torch.tensor(20.0, device=device)
    for _ in range(step):
        mid = (lo + hi) / 2
        f_mid = f(mid)
        if f_mid * f_lo <= 0:
            hi = mid
            f_hi = f_mid
        else:
            lo = mid
            f_lo = f_mid
    return torch.tensor((lo + hi) / 2, device=device)

def log_sum_exp(x, dim=1):
    """数值稳定的 log(sum(exp(x)))"""
    max_val, _ = x.max(dim=dim, keepdim=True)
    return max_val.squeeze(dim) + torch.log(torch.exp(x - max_val).sum(dim=dim))

# --------------------------- EM 迭代 ---------------------------
L_old = -1e20
ELBO = []
converged = False

for iter in range(maxIter):
    # ---- E-step ----
    # 有标签数据
    log_pX_lab = []
    delta_lab_list = []
    for k in range(K):
        log_p = multivariate_student_t_logpdf(X_lab, mu[k], Lambda[k], v[k])
        log_pX_lab.append(log_p)
        diff = X_lab - mu[k]
        delta = (diff @ Lambda[k] * diff).sum(dim=-1)
        delta_lab_list.append(delta)
    log_pX_lab = torch.stack(log_pX_lab, dim=1)        # (Nl, K)
    delta_lab = torch.stack(delta_lab_list, dim=1)     # (Nl, K)

    # y | x 的条件对数密度
    X_lab_wan = torch.cat([X_lab, torch.ones(Nl, 1, device=device)], dim=1)
    log_pY_lab = []
    for k in range(K):
        y_pred = X_lab_wan @ g[k]
        sq_error = ((Y_lab - y_pred) ** 2).sum(dim=-1)   # (Nl,)
        log_p = -0.5 * (Dy * torch.log(2 * np.pi * sig2[k]) + sq_error / sig2[k])
        log_pY_lab.append(log_p)
    log_pY_lab = torch.stack(log_pY_lab, dim=1)         # (Nl, K)

    # 联合对数密度
    log_joint_lab = torch.log(alpha) + log_pX_lab + log_pY_lab  # (Nl, K)
    # 后验 R_lab
    R_lab = torch.softmax(log_joint_lab, dim=1)

    # 无标签数据
    log_pX_unlab = []
    delta_unlab_list = []
    for k in range(K):
        log_p = multivariate_student_t_logpdf(X_unlab, mu[k], Lambda[k], v[k])
        log_pX_unlab.append(log_p)
        diff = X_unlab - mu[k]
        delta = (diff @ Lambda[k] * diff).sum(dim=-1)
        delta_unlab_list.append(delta)
    log_pX_unlab = torch.stack(log_pX_unlab, dim=1)     # (Nu, K)
    delta_unlab = torch.stack(delta_unlab_list, dim=1)  # (Nu, K)

    log_joint_unlab = torch.log(alpha) + log_pX_unlab   # (Nu, K)
    R_unlab = torch.softmax(log_joint_unlab, dim=1)

    # 隐变量 u 的期望
    A_lab = (v.unsqueeze(0) + Dx) / 2              # (1, K)
    B_lab = (v.unsqueeze(0) + delta_lab) / 2       # (Nl, K)
    E_eta_lab = A_lab / B_lab
    E_log_eta_lab = t_digamma(A_lab) - torch.log(B_lab)

    A_unlab = (v.unsqueeze(0) + Dx) / 2            # (1, K)
    B_unlab = (v.unsqueeze(0) + delta_unlab) / 2   # (Nu, K)
    E_eta_unlab = A_unlab / B_unlab
    E_log_eta_unlab = t_digamma(A_unlab) - torch.log(B_unlab)

    # 似然值
    ll_lab = log_sum_exp(log_joint_lab, dim=1).sum()
    ll_unlab = log_sum_exp(log_joint_unlab, dim=1).sum()
    L_new = (ll_lab + ll_unlab).item()
    ELBO.append(L_new)

    if iter > 0 and abs(L_new - L_old) / max(abs(L_old), 1e-10) < tol:
        converged = True
        print(f"EM 在第 {iter} 轮收敛，对数似然 = {L_new:.4f}")
        break
    L_old = L_new

    if iter % 50 == 0:
        print(f"Iter {iter:3d}: Log-Likelihood = {L_new:.4f}")

    # ---- M-step ----
    sumR_lab = R_lab.sum(dim=0)          # (K,)
    sumR_unlab = R_unlab.sum(dim=0)
    sumR = sumR_lab + sumR_unlab + 1e-12

    # 混合系数
    alpha = sumR / N

    # 均值 mu （x 部分）
    w_lab = R_lab * E_eta_lab                                     # (Nl, K)
    w_unlab = R_unlab * E_eta_unlab                               # (Nu, K)
    S1_lab = w_lab.T @ X_lab                                      # (K, Dx)
    S1_unlab = w_unlab.T @ X_unlab                                # (K, Dx)
    sumW = w_lab.sum(dim=0) + w_unlab.sum(dim=0)                  # (K,)
    mu = (S1_lab + S1_unlab) / sumW.unsqueeze(-1)                 # (K, Dx)

    # 精度矩阵 Lambda （协方差逆）
    Lambda_new = torch.zeros_like(Lambda)
    for k in range(K):
        diff_lab = X_lab - mu[k]                                  # (Nl, Dx)
        V_lab = (diff_lab * w_lab[:, k].unsqueeze(-1)).T @ diff_lab
        diff_unlab = X_unlab - mu[k]
        V_unlab = (diff_unlab * w_unlab[:, k].unsqueeze(-1)).T @ diff_unlab
        V_k = (V_lab + V_unlab) / sumR[k]                         # 注意分母用 sumR (同 Matlab 源码)
        V_k = 0.5 * (V_k + V_k.T) + 1e-4 * torch.eye(Dx, device=device)
        Lambda_new[k] = torch.linalg.inv(V_k)
    Lambda = Lambda_new

    # 自由度 v
    C_lab = (R_lab * (E_log_eta_lab - E_eta_lab)).sum(dim=0) / (sumR_lab + 1e-12)
    C_unlab = (R_unlab * (E_log_eta_unlab - E_eta_unlab)).sum(dim=0) / (sumR_unlab + 1e-12)
    # 合并所有样本的 Ck (需按总和归一化)
    C_total = (R_lab * (E_log_eta_lab - E_eta_lab)).sum(dim=0) \
              + (R_unlab * (E_log_eta_unlab - E_eta_unlab)).sum(dim=0)
    C_total = C_total / sumR

    for k in range(K):
        v[k] = solve_v(C_total[k].item())

    # 回归参数 g, sig2 （只用有标签）
    for k in range(K):
        rk = R_lab[:, k]                                          # (Nl,)
        sumrk = sumR_lab[k] + 1e-12
        # 加权最小二乘
        W = torch.diag(rk)
        XWX = X_lab_wan.T @ W @ X_lab_wan                         # (Dx+1, Dx+1)
        XWY = X_lab_wan.T @ W @ Y_lab                             # (Dx+1, Dy)
        g_k = torch.linalg.solve(XWX + 1e-6 * torch.eye(Dx+1, device=device), XWY)
        g[k] = g_k
        y_pred_k = X_lab_wan @ g_k
        sq_error = ((Y_lab - y_pred_k) ** 2).sum(dim=-1)          # (Nl,)
        sig2[k] = (rk * sq_error).sum() / sumrk

print(f"\n最终对数似然: {L_old:.4f}, 收敛: {converged}")

# --------------------------- 预测 ---------------------------
# 测试集后验 R_test
log_pX_test = []
for k in range(K):
    log_pX_test.append(multivariate_student_t_logpdf(test_X, mu[k], Lambda[k], v[k]))
log_pX_test = torch.stack(log_pX_test, dim=1)            # (Ntest, K)
log_joint_test = torch.log(alpha) + log_pX_test
R_test = torch.softmax(log_joint_test, dim=1)

X_test_wan = torch.cat([test_X, torch.ones(test_X.shape[0], 1, device=device)], dim=1)
y_pred = torch.zeros(test_X.shape[0], Dy, device=device)
for k in range(K):
    y_pred += R_test[:, k].unsqueeze(-1) * (X_test_wan @ g[k])

y_pred_np = y_pred.cpu().numpy().squeeze()
y_true_np = test_Y.cpu().numpy().squeeze()

y_min = Y.min()
y_max = Y.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (y_true_np - y_min) / (y_max - y_min)
y_pred_norm = (y_pred_np - y_min) / (y_max - y_min)

# 评估
E = y_true_norm - y_pred_norm
rmse = np.sqrt(np.mean(E ** 2))
ss_res = np.sum(E ** 2)
ss_tot = np.sum((y_true_norm - np.mean(y_true_norm)) ** 2)
R2 = 1 - ss_res / ss_tot if ss_tot > 1e-12 else 0.0

from scipy.io import savemat
file_name='Result_Num_SMM_LR20.mat'
savemat(file_name,{'SMM_Y':y_true_norm,'SMM_Y_pre':y_pred_norm.astype(np.float64),'SMM_RMSE':rmse,'SMM_R2':R2})

print(f"\n测试集性能 (标签率 {label_rate:.2f}):")
print(f"  RMSE = {rmse:.4f}")
print(f"  R²   = {R2:.4f}")

# --------------------------- 绘图 ---------------------------
plt.figure()
plt.plot(ELBO)
plt.xlabel('迭代次数')
plt.ylabel('对数似然')
plt.title('半监督 SMM 对数似然变化')
plt.grid(True)

plt.figure()
plt.plot(y_true_np, 'b-o', markersize=4, label='真实值')
plt.plot(y_pred_np, 'r-*', markersize=4, label='预测值')
plt.legend()
plt.title(f'半监督 SMM 预测 (标签率={label_rate:.2f})')
plt.grid(True)

plt.figure()
plt.scatter(y_true_np, y_pred_np)
plt.plot([y_true_np.min(), y_true_np.max()], [y_true_np.min(), y_true_np.max()], 'k--')
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title('预测值 vs 真实值')
plt.grid(True)
plt.show()