# Created by SuvenH
import numpy as np
def z_score(data):
    mean=np.mean(data,axis=0)
    std=np.std(data,axis=0)
    normal_data=(data-mean)/std
    return normal_data