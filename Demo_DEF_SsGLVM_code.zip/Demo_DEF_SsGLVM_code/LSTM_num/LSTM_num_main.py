import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# -- 配置中文字体 --
try:
    # 优先尝试 SimHei（Windows 自带黑体）
    font = fm.FontProperties(family='SimHei')
    fm.findfont(font)
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except:
    try:
        # 尝试 Microsoft YaHei
        font = fm.FontProperties(family='Microsoft YaHei')
        fm.findfont(font)
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
    except:
        # 都不存在则忽略警告
        import warnings
        warnings.filterwarnings('ignore', category=UserWarning)

# 后面紧跟着您的原始绘图代码 ...
from sklearn.preprocessing import StandardScaler

# 设置随机种子保证可重复性
torch.manual_seed(42)
np.random.seed(42)

# 检查是否有 GPU
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Using device: {device}')

# ==================== 1. 加载数据 ====================
data = sio.loadmat('Hetero_dataset_1.mat')
X = data['X']  # 根据文件变量名调整，可能是 (4,2000) 或 (2000,4)
Y = data['Y']

# 统一维度：使 X 形状为 (4, 2000), Y 形状为 (1, 2000)
if X.shape[0] != 4:
    X = X.T
if Y.shape[0] != 1:
    Y = Y.T

# 转换为 numpy 数组（float）
X = X.astype(np.float32)
Y = Y.astype(np.float32)

# ==================== 2. 划分数据集 ====================
# 前1000训练，中间500验证，最后500测试
train_X_full = X[:, 0:1000]  # (4, 1000)
train_Y_full = Y[:, 0:1000]  # (1, 1000)

val_X = X[:, 1000:1500]  # (4, 500)
val_Y = Y[:, 1000:1500]  # (1, 500)

test_X = X[:, 1500:2000]  # (4, 500)
test_Y = Y[:, 1500:2000]  # (1, 500)

# ==================== 3. 标签率调节 ====================
label_rate = 0.20  # 可调节
step = int(round(1 / label_rate))
train_indices = np.arange(0, train_X_full.shape[1], step)  # 0-based

train_X = train_X_full[:, train_indices]  # (4, m)
train_Y = train_Y_full[:, train_indices]  # (1, m)

print(f'标签率: {label_rate:.2f}, 步长: {step}')
print(f'原始训练样本数: {train_X_full.shape[1]}, 实际训练样本数: {train_X.shape[1]}')

# ==================== 4. 数据标准化 ====================
# 使用训练集的统计量进行零均值单位方差标准化（与 mapstd 一致）
# 输入特征标准化
scaler_X = StandardScaler().fit(train_X.T)  # StandardScaler 需要 (样本, 特征) 输入
train_X_scaled = scaler_X.transform(train_X.T).T  # 转回 (4, m)
val_X_scaled = scaler_X.transform(val_X.T).T
test_X_scaled = scaler_X.transform(test_X.T).T

# 输出标准化
scaler_Y = StandardScaler().fit(train_Y.T)  # (m, 1)
train_Y_scaled = scaler_Y.transform(train_Y.T).T  # (1, m)
val_Y_scaled = scaler_Y.transform(val_Y.T).T
test_Y_scaled = scaler_Y.transform(test_Y.T).T

# ==================== 5. 转换为 PyTorch 张量 ====================
# 网络接受 (batch, features), 输出 (batch, 1)
# 因此需要将 (4, N) 转置为 (N, 4)
train_X_t = torch.tensor(train_X_scaled.T, dtype=torch.float32).to(device)
train_Y_t = torch.tensor(train_Y_scaled.T, dtype=torch.float32).to(device)  # shape (N, 1)

val_X_t = torch.tensor(val_X_scaled.T, dtype=torch.float32).to(device)
val_Y_t = torch.tensor(val_Y_scaled.T, dtype=torch.float32).to(device)

test_X_t = torch.tensor(test_X_scaled.T, dtype=torch.float32).to(device)
test_Y_t = torch.tensor(test_Y_scaled.T, dtype=torch.float32).to(device)  # 标准化后的真实值

test_Y_original = torch.tensor(test_Y.T, dtype=torch.float32).to(device)  # 原始量纲的真实值

# 创建 DataLoader，训练时合并训练与验证（MATLAB 中合并用于训练并监控验证）
# 这里采用手动训练循环，分别提供训练集和验证集
train_loader = DataLoader(TensorDataset(train_X_t, train_Y_t), batch_size=16, shuffle=True)
val_loader = DataLoader(TensorDataset(val_X_t, val_Y_t), batch_size=len(val_X_t))  # 全量验证


# ==================== 6. 构建全连接DNN回归模型 ====================
class LSTM(nn.Module):
    def __init__(self, input_dim=4, hidden_layers=[64, 32, 16], output_dim=1):
        """
        hidden_layers: list，如 [64,32,16] 表示三层隐藏层，神经元数分别为 64、32、16
                      若传入空列表 []，则变成线性模型（无隐藏层）
        """
        super(LSTM, self).__init__()
        layers = []
        prev_dim = input_dim
        for units in hidden_layers:
            layers.append(nn.Linear(prev_dim, units))
            layers.append(nn.ReLU())
            prev_dim = units
        # 最后加上输出层
        layers.append(nn.Linear(prev_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


hidden_layers = [64,32,16]   # 可自由调节
model = LSTM(input_dim=4, hidden_layers=hidden_layers, output_dim=1).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=50)

# ==================== 7. 训练网络 ====================
epochs = 2000
best_val_loss = float('inf')
best_model_state = None
patience = 200
patience_counter = 0

for epoch in range(epochs):
    model.train()
    train_loss = 0.0
    for batch_x, batch_y in train_loader:
        optimizer.zero_grad()
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()
        train_loss += loss.item() * batch_x.size(0)
    train_loss /= len(train_loader.dataset)

    # 验证
    model.eval()
    with torch.no_grad():
        val_x_all, val_y_all = next(iter(val_loader))
        val_preds = model(val_x_all)
        val_loss = criterion(val_preds, val_y_all).item()

    scheduler.step(val_loss)

    # 保存最佳模型
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        best_model_state = model.state_dict()
        patience_counter = 0
    else:
        patience_counter += 1

    if epoch % 100 == 0:
        print(f'Epoch {epoch:4d}: Train Loss = {train_loss:.6f}, Val Loss = {val_loss:.6f}')

    if patience_counter >= patience:
        print(f'Early stopping at epoch {epoch}')
        break

# 加载最佳模型
model.load_state_dict(best_model_state)
print(f'Best validation loss: {best_val_loss:.6f}')

# ==================== 8. 测试与反标准化 ====================
model.eval()
with torch.no_grad():
    test_preds_scaled = model(test_X_t)

# 反标准化到原始量纲
test_preds_np = test_preds_scaled.cpu().numpy()
test_preds_original_np = scaler_Y.inverse_transform(test_preds_np)  # shape (N, 1)
test_preds_original = torch.tensor(test_preds_original_np, dtype=torch.float32).to(device)

# 转换为 1D 数组用于计算和绘图
test_Y_true = test_Y_original.cpu().numpy().squeeze()
test_Y_pred = test_preds_original.cpu().numpy().squeeze()


# 2. 归一化到 [0, 1] 区间 (Min-Max Normalization)
y_min = Y.min()
y_max = Y.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (test_Y_true - y_min) / (y_max - y_min)
y_pred_norm = (test_Y_pred - y_min) / (y_max - y_min)

# ==================== 9. 性能评估 ====================
rmse_val = np.sqrt(np.mean((y_true_norm - y_pred_norm) ** 2))
ss_res = np.sum((y_true_norm - y_pred_norm) ** 2)
ss_tot = np.sum((y_true_norm - np.mean(y_true_norm)) ** 2)
R2 = 1 - ss_res / ss_tot

from scipy.io import savemat
file_name='Result_Num_LSTM_LR20.mat'
savemat(file_name,{'LSTM_Y':y_true_norm,'LSTM_Y_pre':y_pred_norm.astype(np.float64),'LSTM_RMSE':rmse_val,'LSTM_R2':R2})

print(f'测试集性能指标：')
print(f'  均方根误差(MSE) : {rmse_val:.4f}')
print(f'  决定系数(R²)  : {R2:.4f}')

# ==================== 10. 可视化 ====================
plt.figure(figsize=(10, 5))
plt.plot(test_Y_true, 'b-o', linewidth=1, markersize=4, label='真实值')
plt.plot(test_Y_pred, 'r-*', linewidth=1, markersize=4, label='预测值')
plt.legend()
plt.xlabel('测试样本序号')
plt.ylabel('输出值')
plt.title(f'LSTM预测结果 (标签率={label_rate:.2f})')
plt.grid(True)
plt.show()

plt.figure(figsize=(6, 6))
plt.scatter(test_Y_true, test_Y_pred)
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title(f'预测值与真实值散点图 (标签率={label_rate:.2f})')
plt.axis('square')
lims = [np.min([plt.xlim()[0], plt.ylim()[0]]), np.max([plt.xlim()[1], plt.ylim()[1]])]
plt.xlim(lims)
plt.ylim(lims)
plt.plot(lims, lims, 'k--')
plt.grid(True)
plt.show()