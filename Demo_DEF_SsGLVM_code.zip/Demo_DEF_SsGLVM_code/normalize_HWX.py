import numpy as np

def min_max_normalize(data):
    """
        Perform Min-Max normalization on the input data and scale the data into the range[0,1]

        Parameter:
        data (numpy array or list):  one-dimensional or multidimensional array

        Return
        numpy array: normalized data。
        """
    data=np.array(data) #Convert the input into a numpy array
    data_min=np.min(data,axis=0)
    data_max=np.max(data,axis=0)
    normalized_data=(data-data_min)/(data_max-data_min)
    return normalized_data