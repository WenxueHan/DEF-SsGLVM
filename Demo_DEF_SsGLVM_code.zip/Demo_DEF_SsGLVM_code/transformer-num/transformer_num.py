import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from sklearn.preprocessing import StandardScaler

# ---------- 中文字体设置 ----------
try:
    font = fm.FontProperties(family='SimHei')
    fm.findfont(font)
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except:
    try:
        font = fm.FontProperties(family='Microsoft YaHei')
        fm.findfont(font)
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
    except:
        import warnings
        warnings.filterwarnings('ignore', category=UserWarning)

# ---------- 随机种子与设备 ----------
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Using device: {device}')

# ==================== 1. 加载数据 ====================
data = sio.loadmat('Hetero_dataset_1.mat')
X = data['X']
Y = data['Y']

X_all = data['X']
Y_all = data['Y']

# 统一形状：X → (4, 2000), Y → (1, 2000)
if X.shape[0] != 4:
    X = X.T
if Y.shape[0] != 1:
    Y = Y.T

X = X.astype(np.float32)
Y = Y.astype(np.float32)

# ==================== 2. 划分数据集 ====================
# 前 1000 训练，中间 500 验证，最后 500 测试
train_X_full = X[:, :1000]   # (4, 1000)
train_Y_full = Y[:, :1000]   # (1, 1000)
val_X   = X[:, 1000:1500]
val_Y   = Y[:, 1000:1500]
test_X  = X[:, 1500:2000]
test_Y  = Y[:, 1500:2000]

print(f"原始训练集样本数: {train_X_full.shape[1]}, 验证集: {val_X.shape[1]}, 测试集: {test_X.shape[1]}")

# ==================== 3. 标签率调节 ====================
label_rate = 0.2           # <--- 可调节，0.1 表示每 10 个取 1 个
step = int(round(1 / label_rate))
# 从训练集的 0~999 中每隔 step 选取一个索引
train_indices = np.arange(0, train_X_full.shape[1], step)   # 例如 step=10 时选取 [0,10,20,...]
train_X = train_X_full[:, train_indices]      # (4, M)
train_Y = train_Y_full[:, train_indices]      # (1, M)

print(f"标签率: {label_rate:.2f}, 步长: {step}")
print(f"稀疏后的训练样本数: {train_X.shape[1]}")

# ==================== 4. 数据标准化 ====================
scaler_X = StandardScaler().fit(train_X.T)          # 用选出的训练集统计量
train_X_scaled = scaler_X.transform(train_X.T).T    # (4, M)
val_X_scaled   = scaler_X.transform(val_X.T).T      # (4, 500)
test_X_scaled  = scaler_X.transform(test_X.T).T     # (4, 500)

scaler_Y = StandardScaler().fit(train_Y.T)
train_Y_scaled = scaler_Y.transform(train_Y.T).T    # (1, M)
val_Y_scaled   = scaler_Y.transform(val_Y.T).T
test_Y_scaled  = scaler_Y.transform(test_Y.T).T

# ==================== 5. 转为 PyTorch 张量 ====================
train_X_t = torch.tensor(train_X_scaled.T, dtype=torch.float32).to(device)  # (M, 4)
train_Y_t = torch.tensor(train_Y_scaled.T, dtype=torch.float32).to(device)  # (M, 1)

val_X_t = torch.tensor(val_X_scaled.T, dtype=torch.float32).to(device)      # (500, 4)
val_Y_t = torch.tensor(val_Y_scaled.T, dtype=torch.float32).to(device)      # (500, 1)

test_X_t = torch.tensor(test_X_scaled.T, dtype=torch.float32).to(device)    # (500, 4)
test_Y_t = torch.tensor(test_Y_scaled.T, dtype=torch.float32).to(device)    # (500, 1)

# 测试集原始量纲（用于反标准化后评估）
test_Y_original = torch.tensor(test_Y.T, dtype=torch.float32).to(device)

# DataLoader
train_loader = DataLoader(TensorDataset(train_X_t, train_Y_t), batch_size=32, shuffle=True)
val_loader   = DataLoader(TensorDataset(val_X_t, val_Y_t), batch_size=len(val_X_t))  # 全量评估

# ==================== 6. Transformer 模型定义 ====================
class PositionalEncoding(nn.Module):
    """可学习的位置编码（适用于短序列）"""
    def __init__(self, d_model, max_len=10):
        super().__init__()
        self.pos_embed = nn.Parameter(torch.randn(1, max_len, d_model))

    def forward(self, x):
        # x: (batch, seq_len, d_model)
        return x + self.pos_embed[:, :x.size(1), :]


class TransformerRegressor(nn.Module):
    def __init__(self, input_dim=4, d_model=64, nhead=4, num_layers=2,
                 dim_feedforward=128, dropout=0.1, output_dim=1):
        super().__init__()
        # 将每个特征从 1 维映射到 d_model
        self.input_proj = nn.Linear(1, d_model)          # 修正点
        self.pos_encoder = PositionalEncoding(d_model, max_len=input_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=dim_feedforward,
            dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.dropout = nn.Dropout(dropout)
        self.regressor = nn.Linear(d_model, output_dim)

    def forward(self, x):
        # x: (batch, 4)
        x = x.unsqueeze(-1)                     # (batch, 4, 1)
        x = self.input_proj(x)                  # (batch, 4, d_model)  直接投影最后一维
        x = self.pos_encoder(x)
        x = self.transformer_encoder(x)         # (batch, 4, d_model)
        x = x.mean(dim=1)                       # (batch, d_model)
        x = self.dropout(x)
        out = self.regressor(x)                 # (batch, 1)
        return out


# 实例化模型（可根据需要调整超参数）
model = TransformerRegressor(input_dim=4, d_model=64, nhead=4,
                             num_layers=2, dim_feedforward=128, dropout=0.1).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=50)

# ==================== 7. 训练循环 ====================
epochs = 2000
best_val_loss = float('inf')
best_model_state = None
patience = 200
counter = 0

for epoch in range(epochs):
    model.train()
    train_loss = 0.0
    for batch_x, batch_y in train_loader:
        optimizer.zero_grad()
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()
        train_loss += loss.item() * batch_x.size(0)
    train_loss /= len(train_loader.dataset)

    # 验证
    model.eval()
    with torch.no_grad():
        val_x_all, val_y_all = next(iter(val_loader))
        val_preds = model(val_x_all)
        val_loss = criterion(val_preds, val_y_all).item()

    scheduler.step(val_loss)

    # 保存最佳模型
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        best_model_state = model.state_dict()
        counter = 0
    else:
        counter += 1

    if epoch % 100 == 0:
        print(f'Epoch {epoch:4d}: Train Loss = {train_loss:.6f}, Val Loss = {val_loss:.6f}')

    if counter >= patience:
        print(f'Early stopping at epoch {epoch}')
        break

model.load_state_dict(best_model_state)
print(f'Best validation loss: {best_val_loss:.6f}')

# ==================== 8. 测试与反标准化 ====================
model.eval()
with torch.no_grad():
    preds_scaled = model(test_X_t)

# 反标准化到原始量纲
preds_scaled_np = preds_scaled.cpu().numpy()
preds_original_np = scaler_Y.inverse_transform(preds_scaled_np)  # (N, 1)
preds_original = torch.tensor(preds_original_np, dtype=torch.float32).to(device)

test_true = test_Y_original.cpu().numpy().squeeze()
test_pred = preds_original.cpu().numpy().squeeze()

y_min = Y_all.min()
y_max = Y_all.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (test_true - y_min) / (y_max - y_min)
y_pred_norm = (test_pred - y_min) / (y_max - y_min)

# ==================== 9. 性能评估 ====================
rmse_val = np.sqrt(np.mean((y_true_norm - y_pred_norm) ** 2))
ss_res = np.sum((y_true_norm - y_pred_norm) ** 2)
ss_tot = np.sum((y_true_norm - np.mean(y_true_norm)) ** 2)
R2 = 1 - ss_res / ss_tot

from scipy.io import savemat
file_name='Result_Num_Transformer_LR20.mat'
savemat(file_name,{'transformer_Y':y_true_norm,'transformer_Y_pre':y_pred_norm.astype(np.float64),'transformer_RMSE':rmse_val,'transformer_R2':R2})

print(f'测试集性能指标（标签率 {label_rate:.2f}）：')
print(f'  均方根误差(MSE) : {rmse_val:.4f}')
print(f'  决定系数(R²)  : {R2:.4f}')

# ==================== 10. 可视化 ====================
plt.figure(figsize=(10, 5))
plt.plot(test_true, 'b-o', linewidth=1, markersize=4, label='真实值')
plt.plot(test_pred, 'r-*', linewidth=1, markersize=4, label='预测值')
plt.legend()
plt.xlabel('测试样本序号')
plt.ylabel('输出值')
plt.title(f'Transformer 预测结果 (标签率={label_rate:.2f})')
plt.grid(True)
plt.show()

plt.figure(figsize=(6, 6))
plt.scatter(test_true, test_pred)
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title(f'预测值与真实值散点图 (标签率={label_rate:.2f})')
plt.axis('square')
lims = [np.min([plt.xlim()[0], plt.ylim()[0]]), np.max([plt.xlim()[1], plt.ylim()[1]])]
plt.xlim(lims)
plt.ylim(lims)
plt.plot(lims, lims, 'k--')
plt.grid(True)
plt.show()