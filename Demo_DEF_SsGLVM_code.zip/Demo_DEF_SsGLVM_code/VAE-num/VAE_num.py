import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from sklearn.preprocessing import StandardScaler

# ---------- 字体设置 ----------
try:
    font = fm.FontProperties(family='SimHei')
    fm.findfont(font)
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except:
    try:
        font = fm.FontProperties(family='Microsoft YaHei')
        fm.findfont(font)
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
    except:
        import warnings
        warnings.filterwarnings('ignore', category=UserWarning)

# ---------- 随机种子与设备 ----------
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Using device: {device}')

# ==================== 数据加载 ====================
data = sio.loadmat('Hetero_dataset_1.mat')
X = data['X'].astype(np.float32)  # (4, 2000) 或 (2000, 4)
Y = data['Y'].astype(np.float32)

# 统一为 (4, N) 和 (1, N)
if X.shape[0] != 4:
    X = X.T
if Y.shape[0] != 1:
    Y = Y.T

# ==================== 数据集划分 ====================
train_X_full = X[:, :1000]   # (4, 1000)
train_Y_full = Y[:, :1000]   # (1, 1000)
val_X   = X[:, 1000:1500]
val_Y   = Y[:, 1000:1500]
test_X  = X[:, 1500:2000]
test_Y  = Y[:, 1500:2000]

print(f"原始训练集样本数: {train_X_full.shape[1]}, 验证集: {val_X.shape[1]}, 测试集: {test_X.shape[1]}")

# ==================== 标签率设置 ====================
label_rate = 0.2          # 可调节，0.1 表示每隔 10 取 1
step = int(round(1 / label_rate))
train_indices = np.arange(0, train_X_full.shape[1], step)
train_X = train_X_full[:, train_indices]
train_Y = train_Y_full[:, train_indices]
print(f"标签率: {label_rate:.2f}, 训练样本数: {train_X.shape[1]}")

# ==================== 数据标准化 ====================
scaler_X = StandardScaler().fit(train_X.T)
train_X_scaled = scaler_X.transform(train_X.T).T      # (4, M)
val_X_scaled   = scaler_X.transform(val_X.T).T
test_X_scaled  = scaler_X.transform(test_X.T).T

scaler_Y = StandardScaler().fit(train_Y.T)
train_Y_scaled = scaler_Y.transform(train_Y.T).T      # (1, M)
val_Y_scaled   = scaler_Y.transform(val_Y.T).T
test_Y_scaled  = scaler_Y.transform(test_Y.T).T

# ==================== PyTorch 张量 ====================
train_X_t = torch.tensor(train_X_scaled.T, dtype=torch.float32).to(device)  # (M, 4)
train_Y_t = torch.tensor(train_Y_scaled.T, dtype=torch.float32).to(device)
val_X_t   = torch.tensor(val_X_scaled.T, dtype=torch.float32).to(device)
val_Y_t   = torch.tensor(val_Y_scaled.T, dtype=torch.float32).to(device)
test_X_t  = torch.tensor(test_X_scaled.T, dtype=torch.float32).to(device)
test_Y_t  = torch.tensor(test_Y_scaled.T, dtype=torch.float32).to(device)
test_Y_orig = torch.tensor(test_Y.T, dtype=torch.float32).to(device)

train_loader = DataLoader(TensorDataset(train_X_t, train_Y_t), batch_size=32, shuffle=True)
val_loader   = DataLoader(TensorDataset(val_X_t, val_Y_t), batch_size=len(val_X_t))

# ==================== VAE 模型定义 ====================
class MLP(nn.Module):
    """可配置隐藏层的全连接网络"""
    def __init__(self, input_dim, hidden_dims, output_dim, dropout=0.1):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for hd in hidden_dims:
            layers.append(nn.Linear(prev_dim, hd))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = hd
        layers.append(nn.Linear(prev_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

class VariationalAutoencoderRegressor(nn.Module):
    def __init__(self, input_dim=4, latent_dim=8,
                 encoder_hidden=[64, 32],
                 decoder_hidden=[32, 64],
                 regressor_hidden=[32, 16],
                 dropout=0.1):
        super().__init__()
        # 编码器：输出均值和对数方差
        self.encoder_mean = MLP(input_dim, encoder_hidden, latent_dim, dropout)
        self.encoder_logvar = MLP(input_dim, encoder_hidden, latent_dim, dropout)
        # 解码器：从潜在变量重构输入
        self.decoder = MLP(latent_dim, decoder_hidden, input_dim, dropout)
        # 回归头：从潜在变量预测Y
        self.regressor = MLP(latent_dim, regressor_hidden, 1, dropout)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        # x: (batch, 4)
        mu = self.encoder_mean(x)
        logvar = self.encoder_logvar(x)
        z = self.reparameterize(mu, logvar)
        x_recon = self.decoder(z)
        y_pred = self.regressor(z)
        return x_recon, y_pred, mu, logvar

# ==================== 模型实例化 ====================
model = VariationalAutoencoderRegressor(
    input_dim=4,
    latent_dim=8,               # 潜在空间维度
    encoder_hidden=[64, 32],    # 编码器隐藏层：可任意调节
    decoder_hidden=[32, 64],    # 解码器隐藏层
    regressor_hidden=[32, 16],  # 回归头隐藏层
    dropout=0.1
).to(device)

# print("模型结构:")
# print(model)

# ==================== 损失函数与优化器 ====================
mse_loss = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=50)

# 损失权重
beta_kl = 0.001       # KL 散度系数
beta_reg = 1.0        # 回归损失系数

# ==================== 训练循环 ====================
epochs = 2000
best_val_loss = float('inf')
best_model_state = None
patience = 200
counter = 0

for epoch in range(epochs):
    model.train()
    train_loss = 0.0
    for batch_x, batch_y in train_loader:
        optimizer.zero_grad()
        x_recon, y_pred, mu, logvar = model(batch_x)
        # 重构损失
        recon_loss = mse_loss(x_recon, batch_x)
        # KL 散度
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / batch_x.size(0)
        # 回归损失
        reg_loss = mse_loss(y_pred, batch_y)
        # 总损失
        loss = recon_loss + beta_kl * kl_loss + beta_reg * reg_loss
        loss.backward()
        optimizer.step()
        train_loss += loss.item() * batch_x.size(0)
    train_loss /= len(train_loader.dataset)

    # 验证
    model.eval()
    with torch.no_grad():
        val_x_all, val_y_all = next(iter(val_loader))
        x_recon_val, y_pred_val, mu_val, logvar_val = model(val_x_all)
        val_recon = mse_loss(x_recon_val, val_x_all)
        val_kl = -0.5 * torch.sum(1 + logvar_val - mu_val.pow(2) - logvar_val.exp()) / val_x_all.size(0)
        val_reg = mse_loss(y_pred_val, val_y_all)
        val_loss = val_recon + beta_kl * val_kl + beta_reg * val_reg

    scheduler.step(val_loss)

    if val_loss < best_val_loss:
        best_val_loss = val_loss
        best_model_state = model.state_dict()
        counter = 0
    else:
        counter += 1

    if epoch % 100 == 0:
        print(f'Epoch {epoch:4d}: Train Loss = {train_loss:.6f}, '
              f'Val Loss = {val_loss.item():.6f} (Reg: {val_reg.item():.6f})')

    if counter >= patience:
        print(f'Early stopping at epoch {epoch}')
        break

model.load_state_dict(best_model_state)
print(f'最佳验证损失: {best_val_loss:.6f}')

# ==================== 测试与评估 ====================
model.eval()
with torch.no_grad():
    _, y_pred_test, _, _ = model(test_X_t)

# 1. 反标准化 (映射回原始数据的真实量级)
y_pred_np = y_pred_test.cpu().numpy()
y_pred_orig = scaler_Y.inverse_transform(y_pred_np).squeeze()
y_true_orig = test_Y_orig.cpu().numpy().squeeze()

# 2. 归一化到 [0, 1] 区间 (Min-Max Normalization)
y_min = Y.min()
y_max = Y.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (y_true_orig - y_min) / (y_max - y_min)
y_pred_norm = (y_pred_orig - y_min) / (y_max - y_min)

# 3. 计算归一化后的指标
rmse_norm = np.sqrt(np.mean((y_true_norm - y_pred_norm) ** 2))
ss_res_norm = np.sum((y_true_norm - y_pred_norm) ** 2)
ss_tot_norm = np.sum((y_true_norm - np.mean(y_true_norm)) ** 2)
r2_norm = 1 - ss_res_norm / ss_tot_norm

from scipy.io import savemat
file_name='Result_Num_VAE_LR20.mat'
savemat(file_name,{'VAE_Y':y_true_norm,'VAE_Y_pre':y_pred_norm.astype(np.float64),'VAE_RMSE':rmse_norm,'VAE_R2':r2_norm})

print('=====================================')
print(f'测试集性能（标签率 {label_rate:.2f}）：')
print(f'  归一化后 RMSE : {rmse_norm:.4f}')
print(f'  归一化后 R²   : {r2_norm:.4f}')

# ==================== 可视化 ====================
plt.figure(figsize=(10, 5))
plt.plot(y_true_norm, 'b-o', linewidth=1, markersize=4, label='真实值 (归一化)')
plt.plot(y_pred_norm, 'r-*', linewidth=1, markersize=4, label='预测值 (归一化)')
plt.legend()
plt.xlabel('测试样本序号')
plt.ylabel('输出值 [0, 1]')
plt.title(f'VAE 回归预测结果 (标签率={label_rate:.2f})')
plt.grid(True)
plt.show()

plt.figure(figsize=(6, 6))
plt.scatter(y_true_norm, y_pred_norm)
plt.xlabel('真实值 [0, 1]')
plt.ylabel('预测值 [0, 1]')
plt.title(f'预测 vs 真实 (标签率={label_rate:.2f})')
plt.axis('square')
lims = [np.min([plt.xlim()[0], plt.ylim()[0]]), np.max([plt.xlim()[1], plt.ylim()[1]])]
plt.xlim(lims)
plt.ylim(lims)
plt.plot(lims, lims, 'k--') # 绘制 y=x 虚线参考线
plt.grid(True)
plt.show()