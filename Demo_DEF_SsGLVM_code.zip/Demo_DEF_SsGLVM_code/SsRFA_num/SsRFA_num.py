import numpy as np
import scipy.io as sio
import torch
import torch.distributions as dist
from torch.special import digamma  # 需要 PyTorch >=1.8，否则用 scipy.special.digamma
import matplotlib.pyplot as plt

# 若 PyTorch 版本过低，可用 scipy.special.digamma 代替
try:
    from torch.special import digamma
except ImportError:
    from scipy.special import digamma as _digamma
    digamma = lambda x: torch.from_numpy(_digamma(x.numpy())).to(x.device, x.dtype)

# ---------- 中文字体 ----------
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except:
    pass

# ---------- 随机种子与设备 ----------
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cpu')

# ==================== 1. 数据加载与划分 ====================
data = sio.loadmat('Hetero_dataset_1.mat')
X_all = data['X'].astype(np.float32)
Y_all = data['Y'].astype(np.float32)

X = data['X'].astype(np.float32)
Y = data['Y'].astype(np.float32)

if X_all.shape[0] < X_all.shape[1]:
    X_all = X_all.T
if Y_all.shape[0] < Y_all.shape[1]:
    Y_all = Y_all.T

X_all = torch.tensor(X_all, device=device)
Y_all = torch.tensor(Y_all, device=device)

train_X_full = X_all[:1000]
train_Y_full = Y_all[:1000]
test_X  = X_all[1500:2000]
test_Y  = Y_all[1500:2000]

N_train = train_X_full.shape[0]
Dx = train_X_full.shape[1]
Dy = train_Y_full.shape[1]
D = Dx + Dy

print(f"训练样本数: {N_train}, Dx={Dx}, Dy={Dy}")

# ==================== 2. 半监督划分 ====================
label_rate = 0.2
step = int(round(1 / label_rate))
indices = np.arange(0, N_train, step)
mask_labeled = torch.zeros(N_train, dtype=torch.bool)
mask_labeled[indices] = True

X_labeled = train_X_full[mask_labeled]   # (Nl, Dx)
Y_labeled = train_Y_full[mask_labeled]   # (Nl, Dy)
X_unlabeled = train_X_full[~mask_labeled] # (Nu, Dx)

Nl = X_labeled.shape[0]
Nu = X_unlabeled.shape[0]
print(f"有标签: {Nl}, 无标签: {Nu}")

# ==================== 3. 模型初始化 ====================
K = 4            # 因子数
maxIter = 500
tol = 1e-6

# 初始化均值
mu_x = X_labeled.mean(dim=0)                   # (Dx,)
mu_y = Y_labeled.mean(dim=0)                   # (Dy,)

# 初始化载荷矩阵（随机）
W_x = torch.randn(Dx, K, device=device) * 0.1
W_y = torch.randn(Dy, K, device=device) * 0.1

# 噪声方差（对角元素）
var_x = torch.var(X_labeled, dim=0) + 1e-3     # (Dx,)
var_y = torch.var(Y_labeled, dim=0) + 1e-3     # (Dy,)

# 自由度初始值（较大的值近似高斯）
v = torch.tensor(10.0, device=device, requires_grad=False)

# 精度矩阵（对角）
def psi_from_var(var):
    return torch.diag(1.0 / var)

# ==================== 4. 辅助函数 ====================
def multivariate_student_t_log_prob(x, mu, sigma, v):
    """
    计算多元 Student's t 的对数概率密度。
    x: (N, dim)
    mu: (dim,)
    sigma: (dim, dim) 协方差矩阵（正定）
    v: 标量自由度
    """
    dim = x.shape[-1]
    # 马氏距离
    diff = x - mu
    L = torch.linalg.cholesky(sigma)  # 下三角
    M = torch.cholesky_solve(diff.unsqueeze(-1), L).squeeze(-1)  # (N, dim)
    delta = (diff * M).sum(dim=-1)    # (N,)

    log_det = 2 * torch.log(torch.diag(L)).sum()
    term1 = torch.lgamma((v + dim) / 2) - torch.lgamma(v / 2)
    term2 = -0.5 * log_det - dim/2 * torch.log(v * torch.pi)
    term3 = - (v + dim) / 2 * torch.log(1 + delta / v)
    return term1 + term2 + term3

# ==================== 5. EM 迭代 ====================
L_old = -1e20
L_history = []
converged = False

for iter in range(maxIter):
    # ---- E-step ----
    # 有标签样本的充分统计量
    psi_x = psi_from_var(var_x)       # (Dx, Dx)
    psi_y = psi_from_var(var_y)       # (Dy, Dy)
    psi = torch.block_diag(psi_x, psi_y)  # (D, D)
    W = torch.cat([W_x, W_y], dim=0)      # (D, K)

    cov_noise = torch.block_diag(torch.diag(var_x), torch.diag(var_y))  # 噪声协方差
    A = cov_noise + W @ W.T                # (D, D)
    A_inv = torch.linalg.inv(A + 1e-6 * torch.eye(D, device=device))
    B = torch.eye(K, device=device) + W.T @ psi @ W   # (K, K)
    B_inv = torch.linalg.inv(B + 1e-6 * torch.eye(K, device=device))

    # 存储有标签统计量
    E_theta_lab = []
    E_ln_theta_lab = []
    E_z_lab = []
    E_theta_zzT_lab = []

    mu_joint = torch.cat([mu_x, mu_y], dim=0)   # (D,)
    for i in range(Nl):
        ti = torch.cat([X_labeled[i], Y_labeled[i]], dim=0)  # (D,)
        dt = ti - mu_joint                               # (D,)
        ui = B_inv @ (W.T @ psi @ dt)                   # (K,)
        a = (D + v) / 2.0
        b = (dt @ A_inv @ dt + v) / 2.0
        E_theta = a / b
        E_ln_theta = digamma(a) - torch.log(b)
        E_theta_zzT = B_inv + E_theta * (ui.unsqueeze(-1) * ui.unsqueeze(0))  # (K, K)

        E_theta_lab.append(E_theta)
        E_ln_theta_lab.append(E_ln_theta)
        E_z_lab.append(ui)
        E_theta_zzT_lab.append(E_theta_zzT)

    # 无标签样本的充分统计量
    A_unlab = torch.diag(var_x) + W_x @ W_x.T          # (Dx, Dx)
    A_unlab_inv = torch.linalg.inv(A_unlab + 1e-6 * torch.eye(Dx, device=device))
    B_unlab = torch.eye(K, device=device) + W_x.T @ psi_x @ W_x
    B_unlab_inv = torch.linalg.inv(B_unlab + 1e-6 * torch.eye(K, device=device))

    E_theta_unlab = []
    E_ln_theta_unlab = []
    E_z_unlab = []
    E_theta_zzT_unlab = []

    for j in range(Nu):
        xj = X_unlabeled[j]
        dx = xj - mu_x
        uj = B_unlab_inv @ (W_x.T @ psi_x @ dx)     # (K,)
        a = (Dx + v) / 2.0
        b = (dx @ A_unlab_inv @ dx + v) / 2.0
        E_theta = a / b
        E_ln_theta = digamma(a) - torch.log(b)
        E_theta_zzT = B_unlab_inv + E_theta * (uj.unsqueeze(-1) * uj.unsqueeze(0))

        E_theta_unlab.append(E_theta)
        E_ln_theta_unlab.append(E_ln_theta)
        E_z_unlab.append(uj)
        E_theta_zzT_unlab.append(E_theta_zzT)

    # ---- 计算似然用于收敛诊断 ----
    # 有标签似然
    joint_cov = A   # 协方差 (由于 Student's t 参数化，协方差是 A * v/(v-2) 但这里直接用 A 作为 scale 矩阵的估计)
    # 注意：Student's t 的 scale 矩阵是 Sigma，密度为 S(t|mu, Sigma^{-1}, v)，等价于 (2) 的 3^-1
    # 在多元 t 定义中，如果密度为 (2)，则 3 是精度矩阵，3^{-1} 是 scale 矩阵。我们这里的 A 是协方差矩阵（即精度矩阵的逆）？
    # 回顾公式(11): p(ti) = S(ti|mu, A^{-1}, v)，所以精度矩阵是 A^{-1}，scale 矩阵是 A。
    # 因此 scale 矩阵即 A，自由度 v。
    ll_lab = multivariate_student_t_log_prob(
        torch.cat([X_labeled, Y_labeled], dim=1), mu_joint, A, v).sum()

    # 无标签似然
    # A' 是 p(xj) 的 scale 矩阵，自由度 v
    ll_unlab = multivariate_student_t_log_prob(
        X_unlabeled, mu_x, A_unlab, v).sum()

    J_new = ll_lab + ll_unlab
    L_history.append(J_new.item())

    if iter > 0 and abs(J_new - L_old) / max(abs(L_old), 1e-10) < tol:
        converged = True
        print(f"EM 在第 {iter} 轮收敛")
        break
    L_old = J_new
    if iter % 50 == 0:
        print(f"Iter {iter:3d}: Log-likelihood = {J_new.item():.4f}")

    # ---- M-step ----
    # 汇总统计量
    # 有标签
    Etheta_lab_sum = sum(E_theta_lab)                 # 标量
    Ez_lab_sum = sum(E_z_lab)                         # (K,)
    # 将列表转为张量
    Etheta_vec_lab = torch.tensor(E_theta_lab, device=device)  # (Nl,)
    Ez_mat_lab = torch.stack(E_z_lab, dim=0)                    # (Nl, K)
    Etheta_zzT_mat_lab = torch.stack(E_theta_zzT_lab, dim=0)    # (Nl, K, K)
    Q_lab = Etheta_zzT_mat_lab.sum(dim=0)                        # (K, K)

    # 无标签
    Etheta_unlab_sum = sum(E_theta_unlab)
    Ez_unlab_sum = sum(E_z_unlab)
    Etheta_vec_unlab = torch.tensor(E_theta_unlab, device=device)
    Ez_mat_unlab = torch.stack(E_z_unlab, dim=0)
    Etheta_zzT_mat_unlab = torch.stack(E_theta_zzT_unlab, dim=0)
    Q_unlab = Etheta_zzT_mat_unlab.sum(dim=0)

    Q_total = Q_lab + Q_unlab + 1e-10 * torch.eye(K, device=device)

    # 修正后的 M-step 代码段（替换原来的对应部分）

    # 更新 mu_x  (B.12)
    # 公式：sum_h Etheta_h * (xh - W_x * E[zh])  / sum_h Etheta_h
    temp_lab = X_labeled - (W_x @ Ez_mat_lab.T).T  # (Nl, Dx)
    temp_unlab = X_unlabeled - (W_x @ Ez_mat_unlab.T).T  # (Nu, Dx)
    num_x = (Etheta_vec_lab.unsqueeze(-1) * temp_lab).sum(dim=0) + \
            (Etheta_vec_unlab.unsqueeze(-1) * temp_unlab).sum(dim=0)
    den_x = Etheta_lab_sum + Etheta_unlab_sum + 1e-12
    mu_x_new = num_x / den_x

    # 更新 mu_y  (22) 仅用有标签
    temp_y = Y_labeled - (W_y @ Ez_mat_lab.T).T  # (Nl, Dy)
    mu_y_new = (Etheta_vec_lab.unsqueeze(-1) * temp_y).sum(dim=0) / (Etheta_lab_sum + 1e-12)

    # 更新 W_x (B.13)
    # sum_h Etheta_h * xh * E[zh]^T
    temp_wx = (X_labeled.T * Etheta_vec_lab) @ Ez_mat_lab + \
              (X_unlabeled.T * Etheta_vec_unlab) @ Ez_mat_unlab  # (Dx, K)
    W_x_new = temp_wx @ torch.linalg.inv(Q_total)

    # 更新 W_y (24) 仅用有标签
    temp_wy = (Y_labeled.T * Etheta_vec_lab) @ Ez_mat_lab  # (Dy, K)
    W_y_new = temp_wy @ torch.linalg.inv(Q_lab + 1e-10 * torch.eye(K, device=device))

    # 更新 var_x (8x^{-1}) (B.14)
    Sxx = (X_labeled.T * Etheta_vec_lab) @ X_labeled + \
          (X_unlabeled.T * Etheta_vec_unlab) @ X_unlabeled  # (Dx, Dx)
    term_Wx = W_x_new @ Q_total @ W_x_new.T
    # cross term: sum_h Etheta_h * xh * (W_x * E[zh])^T
    cross_lab = (X_labeled.T * Etheta_vec_lab) @ (W_x_new @ Ez_mat_lab.T).T  # (Dx, Dx)
    cross_unlab = (X_unlabeled.T * Etheta_vec_unlab) @ (W_x_new @ Ez_mat_unlab.T).T
    var_x_new_diag = (Sxx + term_Wx - 2 * cross_lab - 2 * cross_unlab) / (Nl + Nu)
    var_x_new = torch.diagonal(var_x_new_diag).clamp(min=1e-6)

    # 更新 var_y (8y^{-1}) (26) 仅用有标签
    Syy = (Y_labeled.T * Etheta_vec_lab) @ Y_labeled
    term_Wy = W_y_new @ Q_lab @ W_y_new.T
    cross_y = (Y_labeled.T * Etheta_vec_lab) @ (W_y_new @ Ez_mat_lab.T).T
    var_y_new_diag = (Syy + term_Wy - 2 * cross_y) / Nl
    var_y_new = torch.diagonal(var_y_new_diag).clamp(min=1e-6)

    # 更新自由度 v (二分法求解方程 B.15)
    Eln_theta_all = torch.tensor(E_ln_theta_lab + E_ln_theta_unlab, device=device)
    Etheta_all = torch.tensor(E_theta_lab + E_theta_unlab, device=device)
    rhs = -1 - (Eln_theta_all - Etheta_all).mean().item()

    def f(v_val):
        v_t = torch.tensor(v_val, device=device)
        return -digamma(v_t/2) + torch.log(v_t/2) + rhs

    # 二分法搜索区间 [0.1, 200]
    lo, hi = 0.1, 200.0
    f_lo = f(lo)
    f_hi = f(hi)
    if f_lo * f_hi < 0:
        for _ in range(50):
            mid = (lo + hi) / 2
            f_mid = f(mid)
            if f_mid * f_lo <= 0:
                hi = mid
                f_hi = f_mid
            else:
                lo = mid
                f_lo = f_mid
        v = torch.tensor((lo + hi) / 2, device=device)
    else:
        # 如果同号，保持当前 v 或使用边界值
        v = torch.tensor(10.0, device=device)  # fallback

    # 参数更新
    mu_x = mu_x_new
    mu_y = mu_y_new
    W_x = W_x_new
    W_y = W_y_new
    var_x = var_x_new
    var_y = var_y_new

print(f"\n最终对数似然: {L_old.item():.4f}, 收敛: {converged}")

# ==================== 6. 预测（测试集）====================
psi_x = psi_from_var(var_x)
B_pred = torch.eye(K, device=device) + W_x.T @ psi_x @ W_x
B_pred_inv = torch.linalg.inv(B_pred + 1e-6 * torch.eye(K, device=device))

y_pred = []
with torch.no_grad():
    for j in range(test_X.shape[0]):
        xq = test_X[j]
        uq = B_pred_inv @ (W_x.T @ psi_x @ (xq - mu_x))  # (K,)
        yq_hat = W_y @ uq + mu_y
        y_pred.append(yq_hat.cpu().numpy())

y_pred = np.array(y_pred).squeeze()
y_true = test_Y.cpu().numpy().squeeze()

y_min = Y.min()
y_max = Y.max()

if y_max == y_min:
    y_max = y_min + 1e-8 # 防止分母为0

y_true_norm = (y_true - y_min) / (y_max - y_min)
y_pred_norm = (y_pred - y_min) / (y_max - y_min)

# 评估
E = y_true_norm - y_pred_norm
rmse = np.sqrt(np.mean(E**2))
ss_res = np.sum(E**2)
ss_tot = np.sum((y_true_norm - np.mean(y_true_norm))**2)
R2 = 1 - ss_res / ss_tot if ss_tot > 1e-12 else 0.0

from scipy.io import savemat
file_name='Result_Num_RFA_LR20.mat'
savemat(file_name,{'SsRFA_Y':y_true_norm,'SsRFA_Y_pre':y_pred_norm.astype(np.float64),'SsRFA_RMSE':rmse,'SsRFA_R2':R2})

print(f"\n测试集性能 (标签率 {label_rate:.2f}):")
print(f"  RMSE = {rmse:.4f}")
print(f"  R²   = {R2:.4f}")

# ==================== 7. 绘图 ====================
plt.figure(figsize=(8,4))
plt.plot(L_history)
plt.xlabel("迭代次数")
plt.ylabel("对数似然")
plt.title("RS2PFA 半监督 EM 对数似然")
plt.grid(True)
plt.show()

plt.figure(figsize=(10,5))
plt.plot(y_true, 'b-o', markersize=4, label="真实值")
plt.plot(y_pred, 'r-*', markersize=4, label="预测值")
plt.legend()
plt.xlabel("测试样本序号")
plt.ylabel("输出值")
plt.title(f"RS2PFA 半监督预测 (标签率={label_rate:.2f})")
plt.grid(True)
plt.show()

plt.figure(figsize=(6,6))
plt.scatter(y_true, y_pred)
plt.xlabel("真实值")
plt.ylabel("预测值")
plt.title("预测值 vs 真实值")
plt.axis("square")
lims = [min(np.min(y_true), np.min(y_pred)), max(np.max(y_true), np.max(y_pred))]
plt.xlim(lims); plt.ylim(lims)
plt.plot(lims, lims, 'k--')
plt.grid(True)
plt.show()